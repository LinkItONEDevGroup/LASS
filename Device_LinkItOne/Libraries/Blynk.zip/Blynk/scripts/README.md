
You can also use a python gateway (this is at early prototype stage).

  1. Install python 2 or 3 and additional modules:
     - https://pypi.python.org/pypi/pyserial
  2. Modify gateway.py for your needs and run it
  
